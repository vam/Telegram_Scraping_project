from dataclasses import dataclass
from typing import Optional


@dataclass
class ChannelInfo:

    id: int
    title: str
    username: Optional[str]
    type: str
    public: bool
    broadcast: bool
    megagroup: bool