import cv2


def detect_qr(image_path):
    detector = cv2.QRCodeDetector()

    image = cv2.imread(image_path)

    if image is None:
        return False, []

    data, points, _ = detector.detectAndDecode(image)

    if points is not None and data:
        return True, [data]

    return False, []