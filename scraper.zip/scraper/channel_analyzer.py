from telethon.tl.functions.channels import GetFullChannelRequest


class ChannelAnalyzer:

    def __init__(self, client):
        self.client = client

    async def analyze_channel(self, entity, limit=100):

        report = {}

#Basic Metadata

        report["id"] = entity.id
        report["title"] = entity.title
        report["username"] = entity.username
        report["broadcast"] = entity.broadcast
        report["megagroup"] = entity.megagroup
        report["verified"] = getattr(entity, "verified", False)
        report["scam"] = getattr(entity, "scam", False)
        report["fake"] = getattr(entity, "fake", False)

#Full Channel Info

        try:
            full = await self.client(GetFullChannelRequest(entity))

            report["description"] = full.full_chat.about

            participants = getattr(full.full_chat, "participants_count", None)

            report["participants"] = participants

        except Exception:

            report["description"] = None
            report["participants"] = None

#Analysis of Recent Messages

        total_messages = 0
        text_messages = 0
        media_messages = 0

        total_views = 0
        total_forwards = 0

        latest_message_date = None

        recent_messages = []

        async for msg in self.client.iter_messages(entity, limit=limit):

            total_messages += 1

            if latest_message_date is None:
                latest_message_date = msg.date

            if msg.text:
                text_messages += 1

            if msg.media:
                media_messages += 1

            if msg.views:
                total_views += msg.views

            if msg.forwards:
                total_forwards += msg.forwards

            recent_messages.append(msg)

        report["total_messages"] = total_messages
        report["text_messages"] = text_messages
        report["media_messages"] = media_messages

        if total_messages:

            report["average_views"] = total_views / total_messages
            report["average_forwards"] = total_forwards / total_messages

        else:

            report["average_views"] = 0
            report["average_forwards"] = 0

        report["latest_message_date"] = latest_message_date

        report["recent_messages"] = recent_messages

        return report