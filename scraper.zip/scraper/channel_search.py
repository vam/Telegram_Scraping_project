import re

from telethon.tl.functions.contacts import SearchRequest
from telethon.tl.types import Channel

from models.channel import ChannelInfo
from scraper.boolean_filter import matches_query


class TelegramSearch:

    def __init__(self, client):
        self.client = client

    async def search_channels(self, keyword, limit=100):

        # Extract all words from the Boolean expression
        telegram_words = re.findall(r"[A-Za-z0-9_+\-.]+", keyword)

        # Remove Boolean operators
        ignore = {"AND", "OR", "NOT"}

        search_terms = [
            word for word in telegram_words
            if word.upper() not in ignore
        ]

        # Remove duplicate search terms while preserving order
        search_terms = list(dict.fromkeys(search_terms))

        # Store unique channels from all Telegram searches
        unique_channels = {}

        for term in search_terms:

            result = await self.client(
                SearchRequest(
                    q=term,
                    limit=limit
                )
            )

            for chat in result.chats:

                if not isinstance(chat, Channel):
                    continue

                unique_channels[chat.id] = chat

        channels = []

        # Apply Boolean filter on merged search results
        for chat in unique_channels.values():

            if not matches_query(chat.title, keyword):
                continue

            print("=" * 50)
            print(f"Title     : {chat.title}")
            print(f"Username  : {chat.username}")
            print(f"Public    : {chat.username is not None}")
            print("=" * 50)

            if chat.broadcast:
                entity_type = "Channel"
            elif chat.megagroup:
                entity_type = "Super Group"
            else:
                entity_type = "Group"

            channel = ChannelInfo(
                id=chat.id,
                title=chat.title,
                username=chat.username,
                type=entity_type,
                public=chat.username is not None,
                broadcast=chat.broadcast,
                megagroup=chat.megagroup
            )

            channels.append(channel)

        return channels