import re
import boolean

algebra = boolean.BooleanAlgebra() #take care of and or not operators and brackets


def matches_query(title: str, query: str) -> bool:
    """
    Supports:
        drugs
        drugs AND delhi
        drugs OR delhi
        (drugs OR crypto) AND delhi
        (btc OR usdt) AND (india OR delhi)

    Matching is case-insensitive.
    """

    if not query.strip(): #if query is empty, return True
        return True

    title = title.lower() # converting title to lower case for case-insensitive matching

    # Normalize operators
    expr = (
        query.lower()
        .replace("&&", " AND ") # if query contains &&, replace it with AND
        .replace("||", " OR ") # if query contains ||, replace it with OR
    )

    expr = re.sub(r"\band\b", "AND", expr) #if query contains and, replace it with AND
    expr = re.sub(r"\bor\b", "OR", expr) # if query contains or, replace it with OR
    expr = re.sub(r"\bnot\b", "NOT", expr) #if ₹query contains not, replace it with NOT

    # Find all keywords
    tokens = set(
        re.findall(r"[a-zA-Z0-9_+\-.]+", expr)
    ) # find all words in the query and store them in a set called tokens

    # Remove boolean operators
    operators = {"AND", "OR", "NOT", "TRUE", "FALSE"} # define a set of boolean operators
    keywords = tokens - operators # remove the boolean operators from the set of tokens to get the keywords

    # Replace every keyword with True/False
    for word in sorted(keywords, key=len, reverse=True): # sorted keywords by length in reverse order to avoid partial matches (e.g., "cat" in "concatenate") and if same length, sort alphabetically to ensure consistent replacement order.
        found = re.search(
                    rf"\b{re.escape(word)}\b", # exact word match using word boundaries to avoid partial matches (e.g., "cat" in "concatenate")
                    title,
                    flags=re.IGNORECASE) is not None
        
        expr = re.sub(
                    rf"\b{re.escape(word)}\b",
                    str(found),
                    expr,
                    flags=re.IGNORECASE,) # replace the keyword in the expression with True or False based on whether it was found in the title.

    try:
        parsed = algebra.parse(expr) #make tree structure of the expression using boolean algebra parser
        simplified = parsed.simplify() # simplify the expression using boolean algebra simplification rules
        return simplified == algebra.TRUE # if the simplified expression is True, return True, else return False
    except Exception:
        return False