from email.mime import text
import re



class ChannelScorer:

    def __init__(self, weights):
        self.weights = weights

        # -----------------------------
        # Crypto Indicators
        # -----------------------------
        self.crypto_keywords = {
            "bitcoin", "btc", "ethereum", "eth", "usdt", "usdc",
            "trx", "tron", "bnb", "sol", "wallet", "seed phrase",
            "private key", "metamask", "binance", "crypto",
            "blockchain", "token", "coin", "airdrop", "defi",
            "dex", "cex", "nft"}


        # -----------------------------
        # Drug Indicators
        # -----------------------------
        self.drug_keywords = {
            # General
            "drug", "drugs", "narcotic", "narcotics",

            # Cannabis
            "weed", "marijuana", "cannabis", "ganja",

            # Cocaine
            "cocaine", "crack cocaine",

            # Heroin & Opioids
            "heroin", "opium", "opioid", "opiates", "fentanyl",
            "morphine", "codeine", "methadone", "tramadol",
            "oxycodone", "hydrocodone", "buprenorphine",
            "Brown","Chitta","Mota","Pot","Skunk","Sinsemilla","Sinse","Weed Oil",

            # Methamphetamine
            "meth", "methamphetamine", "crystal meth",

            # MDMA
            "mdma", "ecstasy", "molly",

            # Hallucinogens
            "lsd", "psilocybin", "magic mushrooms",
            "shrooms", "dmt", "mescaline",

            # Other drugs
            "amphetamine", "ketamine", "ghb", "pcp",
            "rohypnol", "k2", "bath salts",
            "heroin", "brown", "chitta", "aata", "sattu", "no.4", "smack", "kapra", "brown sugar", "sugar", "powder",

            "opium", "kala", "nagini", "doodh", "ammal", "afeem", "doda", "kali", "bhukki", "posta",

            "mephedrone", "meow meow",

            "methamphetamine", "baraf", "cat", "macca", "ice", "glass", "shisha", "tikki",

            "cannabis", "ganja", "bhang", "charas", "hash", "mall", "joint", "cream", "patta",

            "malana cream", "anta", "tola", "ghans", "ghaas", "sukha", "geela",

            "bhole", "shiv booti", "puri", "pudia", "idukki gold", "nepal cream",

            "cocaine", "sajan",  "snow",

            "mdma", "md", "molly", "ecstasy", "m-cat",

            "lsd", "lollipop", "kagaz", "ticket", "stamp",

            "bazooka", "atom bomb", "karachi", "snape", "score",

            "ketamine",  "vitamin k",

            "herbal", "supplements", "chemicals", "book", "dawai",

            "parcel", "item", "stuff", "saman"
}
        # -----------------------------
        # Fraud Indicators
        # -----------------------------
        self.fraud_keywords = {
            "scam",
            "fraud",
            "fake",
            "phishing",
            "otp",
            "cvv",
            "bank login",
            "credit card",
            "debit card",
            "carding",
            "refund scam",
            "investment scam",
            "gift card",
            "exploit",
            "hack",
            "hacked",
            "stolen",
            "illegal",
            "spoof",
            "impersonation"}
        
        self.money_keywords = {
            "hawala",
            "money laundering",
            "laundering",
            "cashout",
            "cash out",
            "cash in",
            "dirty money",
            "clean money",
            "money mule",
            "shell company",
            "cash conversion",
            "mixing",
            "mixer",
            "tumbler",
            "anonymous transfer",
            "layering",
            "placement",
            "integration",
            "offshore"}

        self.terror_keywords = {
            "terror",
            "terrorism",
            "terrorist",
            "terror financing",
            "terror funding",
            "extremist",
            "donation",
            "crypto donation",
            "anonymous donation",
            "fundraising",
            "fund the cause",
            "jihad",
            "martyr",
            "sanctions",
            "sanctions evasion",
            "isis",
            "isil",
            "al qaeda",
            "hamas"}

        self.india_keywords = {

        # Country
            "india",
            "indian",
            "bharat",

        # Payments
            "upi",
            "paytm",
            "phonepe",
            "gpay",
            "google pay",
            "bhim",
            "imps",
            "neft",
            "rtgs",

        # Banks
            "sbi",
            "hdfc",
            "icici",
            "axis",
            "kotak",
            "canara",
            "pnb",
            "bob",
            "idfc",

        # Cities
            "hyderabad",
            "mumbai",
            "delhi",
            "new delhi",
            "bangalore",
            "bengaluru",
            "chennai",
            "kolkata",
            "pune",
            "ahmedabad",
            "gurgaon",
            "gurugram",
            "noida",
            "lucknow",
            "jaipur",
            "kochi",
            "vizag",
            "vijayawada",
            "guntur",
            "warangal",

        # Currency
            "inr",
            "rupees",
            "lakh",
            "crore"}


        self.financial_keywords = {
            "buy",
            "sell",
            "buyer",
            "seller",
            "trade",
            "trading",
            "exchange",
            "deposit",
            "withdraw",
            "withdrawal",
            "payment",
            "payments",
            "transfer",
            "escrow",
            "p2p",
            "otc"}

    def score_channel(self, report):

        score = 0

        analysis = {

            "crypto_keyword_count": 0,
            "financial_keyword_count": 0,
            "drug_keyword_count": 0,
            "fraud_keyword_count": 0,
            "money_keyword_count": 0,
            "terror_keyword_count": 0,
            "india_keyword_count": 0,

            "url_count": 0,
            "telegram_mentions": 0,
            "hashtags": 0,
            "wallet_addresses": 0,

            "matched_crypto": [],
            "matched_financial": [],
            "matched_drugs": [],
            "matched_fraud": [],
            "matched_money": [],
            "matched_terror": [],   
            "matched_india": [],

            "evidence": [],
            "reasons": [],
            "upi_ids": 0,
            "matched_upi": [],
            "qr_count": 0,
            "matched_qr": [],
            "matched_wallets": [],
            "wallet_report": [],
        }


        # -----------------------------
        # Message Analysis
        # -----------------------------

        for msg in report["recent_messages"]:

            text = (msg.text or "").lower()

            # -----------------------------
            # Drug
            # -----------------------------
            has_drug_keyword = False
            matched_drug = None

            for word in self.drug_keywords:

                if re.search(rf"\b{re.escape(word)}\b", text):
                    analysis["drug_keyword_count"] += 1

                    if word not in analysis["matched_drugs"]:
                        analysis["matched_drugs"].append(word)

                    has_drug_keyword = True
                    matched_drug = word

                    # Evidence (Drug only)
                    analysis["evidence"].append({
                        "category": "Drug",
                        "keyword": word,
                        "message_id": msg.id,
                        "date": msg.date,
                        "text": (msg.text or "")[:1000]})

                    # Score every occurrence
                    score += self.weights["drug"]

            # -----------------------------
            # Crypto
            # -----------------------------
            for word in self.crypto_keywords:

                if re.search(rf"\b{re.escape(word)}\b", text):

                    analysis["crypto_keyword_count"] += 1

                    if word not in analysis["matched_crypto"]:
                        analysis["matched_crypto"].append(word)

                    # Score every occurrence
                    score += self.weights["crypto"]

            # -----------------------------
            # Terror Financing
            # -----------------------------
            for word in self.terror_keywords:

                if re.search(rf"\b{re.escape(word)}\b", text):

                    analysis["terror_keyword_count"] += 1

                    if word not in analysis["matched_terror"]:
                        analysis["matched_terror"].append(word)

                    score += self.weights["terror"]

           
            # -----------------------------
            # Fraud 
            # -----------------------------
            for word in self.fraud_keywords:

                if re.search(rf"\b{re.escape(word)}\b", text):

                    analysis["fraud_keyword_count"] += 1

                    if word not in analysis["matched_fraud"]:
                        analysis["matched_fraud"].append(word)

                    score += self.weights["fraud"]


            # -----------------------------
            # Money Laundering
            # -----------------------------
            for word in self.money_keywords:
                
                if re.search(rf"\b{re.escape(word)}\b", text):

                    analysis["money_keyword_count"] += 1

                    if word not in analysis["matched_money"]:
                        analysis["matched_money"].append(word)

                    score += self.weights["money"]

            # -----------------------------
            # India Specific
            # -----------------------------
            for word in self.india_keywords:

                if re.search(rf"\b{re.escape(word)}\b", text):

                    analysis["india_keyword_count"] += 1

                    if word not in analysis["matched_india"]:
                        analysis["matched_india"].append(word)

                    score += self.weights["india"]

            # -----------------------------
            # Financial Keywords
            # -----------------------------
            for word in self.financial_keywords:
                
                if re.search(rf"\b{re.escape(word)}\b", text):

                    analysis["financial_keyword_count"] += 1

                    if word not in analysis["matched_financial"]:
                        analysis["matched_financial"].append(word)

                    score += 2


    
            # URLs
            urls = re.findall(r'https?://\S+|www\.\S+', text)
            analysis["url_count"] += len(urls)

            # Telegram usernames
            mentions = re.findall(r'@\w+', text)
            analysis["telegram_mentions"] += len(mentions)

            # Hashtags
            hashtags = re.findall(r'#\w+', text)
            analysis["hashtags"] += len(hashtags)

         
            # Wallet Detection


            wallet_patterns = {

                "Bitcoin Legacy": [
                r'\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b'
                ],

                "Bitcoin Bech32": [
                r'\bbc1[a-zA-HJ-NP-Z0-9]{25,62}\b'
                ],

                "Ethereum": [
                    r'\b0x[a-fA-F0-9]{40}\b'
                ],

                "TRON": [
                    r'\bT[1-9A-HJ-NP-Za-km-z]{33}\b'
                ],

                "Monero": [
                    r'\b4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}\b'
                ],

                "Litecoin": [
                    r'\b[L3][a-km-zA-HJ-NP-Z1-9]{26,33}\b',
                    r'\bltc1[a-zA-HJ-NP-Z0-9]{39,59}\b'
                ],

                "Dogecoin": [
                    r'\bD{1}[5-9A-HJ-NP-Ua-km-z]{25,34}\b'
                ]
}

            # -----------------------------
            # WALLET Detection
            # -----------------------------
            wallet_count = 0

            for coin, patterns in wallet_patterns.items():

                for pattern in patterns:

                    matches = re.findall(pattern, text)

                    if matches:

                        wallet_count += len(matches)

                        for wallet in matches:
                            if wallet not in analysis["matched_wallets"]:
                                analysis["matched_wallets"].append(wallet)
                                analysis["wallet_report"].append({

                                "message_id": msg.id,

                                "date": msg.date,

                                "wallet_address": wallet,

                                "upi_id": "",

                                "message_context": msg.text})
            # Total wallet count
            analysis["wallet_addresses"] += wallet_count

            # Fixed Wallet Score
            if wallet_count > 0:
                wallet_score = wallet_count * 2
                score += wallet_score

                analysis["reasons"].append(
                    f"{wallet_count} crypto wallet(s) detected (+{wallet_score}).")
            

            # -----------------------------
            # UPI Detection
            # -----------------------------

            upi_pattern = r'\b[a-zA-Z0-9._-]{2,256}@[a-zA-Z]{2,64}\b'

            upi_matches = re.findall(upi_pattern, text)

            analysis["upi_ids"] = analysis.get("upi_ids", 0) + len(upi_matches)

            if upi_matches:

                for upi in upi_matches:

                    if upi not in analysis["matched_upi"]:
                        analysis["matched_upi"].append(upi)
                        analysis["wallet_report"].append({

                        "message_id": msg.id,

                        "date": msg.date,

                        "wallet_address": "",

                        "upi_id": upi,

                        "message_context": msg.text})

                # Fixed UPI Score
                upi_score = len(upi_matches) * 2

                score += upi_score

                analysis["reasons"].append(

                    f"{len(upi_matches)} UPI ID(s) detected (+{upi_score}).")



        # -----------------------------
        # Recent Activity (Fixed Score)
        # -----------------------------

        # Number of recent messages analyzed
        if report["total_messages"] >= 400:
            score += 10
            analysis["reasons"].append("Very high recent activity (+10).")

        elif report["total_messages"] >= 200:
            score += 7
            analysis["reasons"].append("High recent activity (+7).")

        elif report["total_messages"] >= 100:
            score += 5
            analysis["reasons"].append("Moderate recent activity (+5).")

        elif report["total_messages"] >= 50:
            score += 2
            analysis["reasons"].append("Some recent activity (+2).")


        analysis["activity_score"] = 0

        if report["total_messages"] >= 400:
            analysis["activity_score"] = 10
        elif report["total_messages"] >= 200:
            analysis["activity_score"] = 7
        elif report["total_messages"] >= 100:
            analysis["activity_score"] = 5
        elif report["total_messages"] >= 50:
            analysis["activity_score"] = 2


        # -----------------------------
        # Normalize Score (0-100)
        # -----------------------------

        analysis["raw_score"] = round(score, 2)

        # Adjust this value after testing with real channels
        MAX_SCORE = 300

        normalized_score = min(round((score / MAX_SCORE) * 100), 100)

        # -----------------------------
        # Recommendation
        # -----------------------------

        if score >= 150:
            recommendation = "Highly Relevant"

        elif score >= 75:
            recommendation = "Relevant"

        elif score >= 30:
            recommendation = "Needs Review"

        else:
            recommendation = "Low Priority"

        analysis["score"] = normalized_score
        analysis["recommendation"] = recommendation

        return analysis