from telethon import TelegramClient
from config.settings import API_ID, API_HASH, SESSION_NAME


class TelegramClientManager:
    def __init__(self):
        self.client = TelegramClient(
            SESSION_NAME,
            API_ID,
            API_HASH
        )

    async def connect(self):
        await self.client.start()
        print("✅ Successfully connected to Telegram")
        return self.client

    async def disconnect(self):
        await self.client.disconnect()
        print("🔌 Disconnected")