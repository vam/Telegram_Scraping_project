import os

from scraper.utils.media_downloader import MediaDownloader
from scraper.qr_detector import detect_qr


class MessageScraper:

    def __init__(self, client):

        self.client = client
        self.media_downloader = MediaDownloader()

    async def scrape_messages(
        self,
        entity,
        channel_name,
        limit=100
    ):

        messages = []

        async for message in self.client.iter_messages(
            entity,
            limit=limit
        ):

            media_path = await self.media_downloader.download_media(
                self.client,
                message,
                channel_name
            )

            # ---------------------------------
            # Keep only media containing QR code
            # ---------------------------------
            if media_path:

                qr_found, _ = detect_qr(media_path)

                if not qr_found:
                    os.remove(media_path)
                    media_path = None

            messages.append({

                "message_id": message.id,

                "date": message.date,

                "sender_id": message.sender_id,

                "text": message.text,

                "views": message.views,

                "forwards": message.forwards,

                "has_media": media_path is not None,

                "media_path": media_path

            })

        return messages