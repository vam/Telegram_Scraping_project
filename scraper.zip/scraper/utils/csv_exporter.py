import os
import pandas as pd


class CSVExporter:

    def __init__(self):

        self.output_folder = "data/csv"

        os.makedirs(self.output_folder, exist_ok=True)

    def export_messages(
        self,
        channel_name,
        messages
    ):

        rows = []

        

        for item in messages:

            rows.append({

                "Message ID": item["message_id"],

                "Date": item["date"],

                "Wallet Address": item["wallet_address"],

                "UPI ID": item["upi_id"],

                "Message Context": item["message_context"]

    })

        df = pd.DataFrame(rows)

        filename = (
            channel_name
            .replace("/", "_")
            .replace("\\", "_")
            .replace(" ", "_")
        )

        csv_path = os.path.join(
            self.output_folder,
            f"{filename}.csv"
        )

        df.to_csv(
            csv_path,
            index=False,
            encoding="utf-8-sig"
        )

        return csv_path