import os


class MediaDownloader:

    def __init__(self):

        self.base_folder = "data/media"

        os.makedirs(self.base_folder, exist_ok=True)


    async def download_media(
        self,
        client,
        message,
        channel_name
    ):

        if message.media is None:
            return ""

        folder = os.path.join(
            self.base_folder,
            channel_name.replace("/", "_").replace("\\", "_").replace(" ", "_")
        )

        os.makedirs(folder, exist_ok=True)

        file_path = await client.download_media(
            message,
            file=folder
        )

        return file_path if file_path else ""