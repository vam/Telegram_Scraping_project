from telethon.errors import ChannelPrivateError


class AccessManager:

    def __init__(self, client):
        self.client = client

    async def check_access(self, channel):

        print(f"\nChecking access for: {channel.title}")


        
        # Public Channels


        if channel.public:

            try:

                entity = await self.client.get_entity(channel.username  )

                print("✅ Public Channel Accessible")

                return {
                    "status": "accessible",
                    "entity": entity}

            except Exception as e:
                print(type(e).__name__)
                print(e)
                print("❌ Failed to access public channel")

                return {
                    "status": "failed",
                    "entity": None}
        

        # Private Channels

        try:

            entity = await self.client.get_entity(channel.id)

            print("✅ Already a member of private channel")

            return {
                "status": "accessible",
                "entity": entity}

        except ChannelPrivateError:
            print("🔒 Join Required")

            return {"status": "join_required","entity": None}

        except Exception:
            print("🚫 Access Restricted or Not a Member")

            return {
                "status": "restricted",
                "entity": None}